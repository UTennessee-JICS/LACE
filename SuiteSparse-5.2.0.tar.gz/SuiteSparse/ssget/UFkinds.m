function kinds = UFkinds
%UFKINDS get 'kind' of each problem in the SuiteSparse Matrix Collection.
% UFkinds is deprecated; use sskinds instead
kinds = sskinds ;

