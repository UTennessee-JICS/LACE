./qrdemo_gpu2 A.mtx 2 > o_colamd_withgpu
