./qrdemo_gpu A.mtx 6
